# KPI Definitions — Business KPI Dashboard (Customer Churn)

> **Dataset:** `dashboard_data.csv` (synthetic sample, n = 15)
> All KPIs re-calculate dynamically as filters are applied. All monetary values are **monthly** USD unless stated.

---

## 1. Churn Rate

| Field        | Value |
|-------------|-------|
| **Formula** | `Churned Customers / Total Customers` |
| **Numerator** | Count of customers where `Churn = "Yes"` in the filtered set |
| **Denominator** | Count of all customers in the filtered set |
| **Result type** | Percentage (0–100 %) |
| **Unfiltered value** | 7 / 15 = **46.67 %** |
| **Caveats** | With n = 15, a single customer changes the rate by ≈ 6.7 pp. Do not treat as a stable estimate. |

---

## 2. Retention Rate

| Field        | Value |
|-------------|-------|
| **Formula** | `1 − Churn Rate` = `Retained Customers / Total Customers` |
| **Numerator** | Count of customers where `Churn = "No"` |
| **Denominator** | Total customers in the filtered set |
| **Unfiltered value** | 8 / 15 = **53.33 %** |
| **Caveats** | Complement of Churn Rate; both are sample estimates only. |

---

## 3. Revenue Lost to Churn

| Field        | Value |
|-------------|-------|
| **Formula** | `SUM(MonthlyCharges WHERE Churn = "Yes")` |
| **Numerator** | Sum of `MonthlyCharges` for churned customers in the filtered set |
| **Denominator** | N/A (this is a sum, not a ratio) |
| **Unit** | $ / month |
| **Unfiltered value** | **$409.93 / month** |
| **Caveats** | Represents monthly recurring revenue that has already been lost. Does not account for one-time fees, discounts, or future contract value. |

---

## 4. Revenue at Risk

| Field        | Value |
|-------------|-------|
| **Formula** | `SUM(MonthlyCharges WHERE Churn = "No" AND at-risk rule applies)` |
| **At-risk rule** | `ContractType = "Month-to-Month"` **AND** `SupportTickets ≥ 3` |
| **Numerator** | Sum of `MonthlyCharges` for retained customers meeting the at-risk rule |
| **Unit** | $ / month |
| **Unfiltered value** | **$0.00** (no retained Month-to-Month customers with ≥ 3 tickets in this dataset — all Month-to-Month customers have already churned) |
| **Rule rationale** | Month-to-Month customers have no lock-in and can cancel immediately. High support ticket counts (≥ 3) are a strong dissatisfaction signal in this dataset (avg tickets churned = 4.3 vs retained = 1.0). |
| **Adjusting the rule** | Edit `AT_RISK_CONTRACT` and `AT_RISK_MIN_TICKETS` constants at the top of `dashboard/index.html`. |
| **Caveats** | Rule is heuristic. With n = 15 there is not enough data to validate a predictive threshold statistically. |

---

## 5. Average Tenure

| Field        | Value |
|-------------|-------|
| **Formula (overall)** | `MEAN(TenureMonths)` across the filtered set |
| **Formula (by churn)** | `MEAN(TenureMonths WHERE Churn = "Yes/No")` |
| **Median tenure** | `MEDIAN(TenureMonths)` — robust to outliers |
| **Unfiltered values** | Overall: **18.80 mo** · Churned: **7.00 mo** · Retained: **29.12 mo** · Median: **15.0 mo** |
| **Caveats** | Churned customers tend to have significantly shorter tenure (7 mo vs 29 mo), confirming early-life churn risk. |

---

## 6. Average Monthly Charges by Churn Status

| Field        | Value |
|-------------|-------|
| **Formula** | `MEAN(MonthlyCharges WHERE Churn = "Yes"/"No")` |
| **Unfiltered values** | Churned: **$58.56/mo** · Retained: **$107.49/mo** |
| **Caveats** | Retained customers are predominantly Enterprise/Pro tier (higher charges). Lower-charge Basic customers churn at higher rates. |

---

## 7. Average Support Tickets by Churn Status

| Field        | Value |
|-------------|-------|
| **Formula** | `MEAN(SupportTickets WHERE Churn = "Yes"/"No")` |
| **Unfiltered values** | Churned: **4.29 tickets** · Retained: **1.00 ticket** |
| **Caveats** | Strong signal in this dataset. SupportTickets is the primary driver of the Revenue at Risk rule. |

---

## Tenure Band Cutoffs

| Band | Rule | Rationale |
|------|------|-----------|
| `0-6`   | TenureMonths ≤ 6  | Early-life / trial period; highest churn risk |
| `7-12`  | TenureMonths 7–12 | Approaching first annual renewal |
| `13-24` | TenureMonths 13–24 | Established customers, moderate risk |
| `25+`   | TenureMonths > 24 | Long-term loyal customers; lowest churn |

---

## Filter Definitions

| Filter | Column | Allowed Values |
|--------|--------|---------------|
| Contract Type | `ContractType` | Month-to-Month, One Year, Two Year |
| Tenure Band   | `TenureBand`   | 0-6, 7-12, 13-24, 25+ |
| Payment Method| `PaymentMethod`| Bank Transfer, Credit Card, Debit Card, UPI |
| Subscription  | `SubscriptionType` | Basic, Pro, Enterprise |

---

## Verification Table (Pandas vs Dashboard)

Computed on 2026-11-11. All values match.

| Scenario | n | Churn Rate | Rev Lost | Rev at Risk |
|----------|---|-----------|----------|-------------|
| All data (unfiltered)  | 15 | 46.67 % | $409.93 | $0.00 |
| ContractType = Month-to-Month | 7 | 100.00 % | $409.93 | $0.00 |
| TenureBand 0-6 and 7-12       | 6 | 100.00 % | $329.94 | $0.00 |
| PaymentMethod = Credit Card + Two Year | 3 | 0.00 % | $0.00 | $0.00 |
