# Business KPI Dashboard — Customer Churn

An interactive, self-contained HTML dashboard that explains **churn rate, retention rate, revenue at risk, and customer segments** using a synthetic customer churn dataset (n = 15).

> ⚠ **Sample data notice:** The dataset is a small synthetic sample (n = 15). All patterns, percentages, and KPIs are illustrative only and **must not** be presented as proven business insights.

---

## 📂 Repository Structure

```
Task 3/
├── dashboard/
│   └── index.html          ← Self-contained interactive dashboard (open in any browser)
├── data/
│   └── dashboard_data.csv  ← Cleaned data + derived fields (Churn_Flag, TenureBand)
├── docs/
│   ├── kpi_definitions.md  ← Formal KPI formulas, caveats, filter definitions
│   └── screenshots/        ← Dashboard screenshots (see below)
└── README.md               ← This file
```

---

## 🚀 How to Open Locally

**Option 1 – Direct open (Windows):**
```
Double-click dashboard/index.html
```
No server, no build step, no dependencies to install.

**Option 2 – From terminal:**
```bash
start dashboard/index.html
# or on macOS/Linux:
open dashboard/index.html
```

---

## 🌐 How to Publish to GitHub Pages

### Step 1 — Create a GitHub repository

1. Go to [github.com/new](https://github.com/new)
2. Name it `churn-kpi-dashboard` (or anything you like)
3. Set visibility to **Public**
4. Click **Create repository**

### Step 2 — Push your files

```bash
cd "D:\sabari pvt\Sabari study\Internship\Task 3"
git init
git add .
git commit -m "Initial commit: Business KPI Dashboard"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/churn-kpi-dashboard.git
git push -u origin main
```

### Step 3 — Enable GitHub Pages

1. Go to your repository → **Settings** → **Pages**
2. Under **Source**, select **Deploy from a branch**
3. Branch: `main`, Folder: `/ (root)`
4. Click **Save**

> GitHub Pages will build and deploy. Wait ~1–2 minutes.

### Step 4 — Access your dashboard

Your dashboard will be live at:

```
https://YOUR_USERNAME.github.io/churn-kpi-dashboard/dashboard/
```

> Replace `YOUR_USERNAME` with your GitHub username. The `/dashboard/` path is needed because `index.html` is inside the `dashboard/` folder.

---

## 📊 KPIs Implemented

| KPI | Formula | Location |
|-----|---------|----------|
| Churn Rate | Churned ÷ Total | KPI card + all charts |
| Retention Rate | 1 − Churn Rate | KPI card |
| Revenue Lost to Churn | SUM(MonthlyCharges, Churn=Yes) | KPI card |
| Revenue at Risk | SUM(MonthlyCharges, retained + MTM + tickets≥3) | KPI card |
| Avg Tenure (overall/churned/retained) | MEAN(TenureMonths) | KPI card |
| Median Tenure | MEDIAN(TenureMonths) | KPI card sub-text |
| Avg Monthly Charges by Churn | MEAN(MonthlyCharges grouped by Churn) | Segment chart |
| Avg Support Tickets by Churn | MEAN(SupportTickets grouped by Churn) | Dedicated chart |

Full formulas and caveats in [docs/kpi_definitions.md](docs/kpi_definitions.md).

---

## 🔍 Filters

| Filter | Type | Options |
|--------|------|---------|
| Contract Type | Multi-select | Month-to-Month, One Year, Two Year |
| Tenure Band | Multi-select | 0-6, 7-12, 13-24, 25+ months |
| Payment Method | Multi-select | Bank Transfer, Credit Card, Debit Card, UPI |
| Subscription Type | Multi-select | Basic, Pro, Enterprise |

A **Reset Filters** button restores all defaults. All KPIs and charts recalculate instantly.

---

## 🔄 How to Rebuild in Looker Studio (from dashboard_data.csv)

1. Go to [lookerstudio.google.com](https://lookerstudio.google.com) → **Create** → **Report**
2. Add a **data source** → **File Upload** → upload `data/dashboard_data.csv`
3. Configure field types:
   - `TenureMonths`, `MonthlyCharges`, `TotalCharges`, `SupportTickets`, `Churn_Flag` → **Number**
   - `TenureBand` → **Text** (order manually: 0-6, 7-12, 13-24, 25+)
   - All other fields → **Text**
4. Add **Scorecards** for Churn Rate (`AVG(Churn_Flag)`), Revenue Lost (`SUM(MonthlyCharges) filtered to Churn=Yes`)
5. Add **Bar charts** for Churn Rate by ContractType, TenureBand, PaymentMethod
6. Add **Filters**: ContractType, TenureBand, PaymentMethod as filter controls
7. Share the report as **Anyone with the link can view**

---

## 🎨 Accessibility Notes

- **Colorblind-safe palette:** Okabe-Ito (orange, sky blue, green, red, blue, pink)
- **Contrast ratio:** Text ≥ 4.5:1 against backgrounds
- **Labels:** All bars have text labels — meaning is never conveyed by color alone
- **Keyboard navigation:** All filter dropdowns and table headers are keyboard-focusable
- **ARIA labels:** Charts, KPI cards, table, and filter controls are labelled for screen readers
- **Responsive:** Grid layout adapts to mobile screens

---

## ✅ Pass Criteria Checklist

| Requirement | Status | Evidence |
|-------------|--------|---------|
| Churn Rate KPI defined | ✅ | KPI card + `kpi_definitions.md` §1 |
| Retention Rate KPI defined | ✅ | KPI card + `kpi_definitions.md` §2 |
| Revenue Lost KPI defined | ✅ | KPI card + `kpi_definitions.md` §3 |
| Revenue at Risk KPI defined | ✅ | KPI card + `kpi_definitions.md` §4 |
| Avg / Median Tenure KPI | ✅ | KPI card + `kpi_definitions.md` §5 |
| Filter: Contract Type | ✅ | Multi-select, all charts recalculate |
| Filter: Tenure Band | ✅ | Multi-select, cutoffs: 0-6, 7-12, 13-24, 25+ |
| Filter: Payment Method | ✅ | Multi-select, all charts recalculate |
| Reset button | ✅ | "↺ Reset Filters" button |
| Churn by ContractType chart | ✅ | Bar chart with labels |
| Churn by TenureBand chart | ✅ | Bar chart with labels |
| Churn by PaymentMethod chart | ✅ | Bar chart with labels |
| Support Tickets chart | ✅ | Bar chart: churned vs retained |
| Segment view (Subscription) | ✅ | Grouped bar: churn rate + revenue |
| Retained vs Churned split | ✅ | Donut chart |
| Detail table (filterable, sortable) | ✅ | Click headers to sort; at-risk highlighted |
| Empty filter state handled | ✅ | "No customers match" message shown |
| Colorblind-safe palette | ✅ | Okabe-Ito throughout |
| Tooltips / ARIA labels | ✅ | All KPI cards have tooltip definitions |
| Sample data notice | ✅ | Badge in header; footer note |
| KPI verification vs pandas | ✅ | 4 scenarios verified — see `kpi_definitions.md` table |
| Self-contained HTML (no build) | ✅ | CDN only; open with double-click |

---

## 📸 Screenshots

Screenshots captured after dashboard build:

| View | File |
|------|------|
| Full dashboard (unfiltered) | `docs/screenshots/dashboard_full.png` |
| Month-to-Month filter active | `docs/screenshots/filter_mtm.png` |
| Zero-result state | `docs/screenshots/empty_state.png` |

---

## 📋 Data Dictionary

| Column | Type | Description |
|--------|------|-------------|
| CustomerID | String | Unique customer identifier (CUST-XXXX) |
| Gender | String | Customer gender (Male/Female) |
| Age | Integer | Customer age in years |
| TenureMonths | Integer | Months customer has been active |
| SubscriptionType | String | Plan tier: Basic, Pro, Enterprise |
| MonthlyCharges | Float | Monthly billing amount in USD |
| TotalCharges | Float | Lifetime charges (= TenureMonths × MonthlyCharges) |
| ContractType | String | Contract length: Month-to-Month, One Year, Two Year |
| SupportTickets | Integer | Number of support tickets raised |
| PaymentMethod | String | Bank Transfer, Credit Card, Debit Card, UPI |
| Churn | String | Did the customer churn? Yes / No |
| Churn_Flag | Integer | Binary churn indicator: 1 = churned, 0 = retained |
| TenureBand | String | Derived: 0-6, 7-12, 13-24, 25+ (months) |
